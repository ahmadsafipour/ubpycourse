from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/')
def upload():
    return render_template('index.html')
@app.route('/search', methods=['GET', 'POST'])
def userupload():
    f1 = request.files['file']
    f1.save(f1.filename)
    key = 'acc_4fbd4fb04e3608b'
    secret = '4462c99c8a6d0fa578de54820fc219d5'
    pic1 = requests.post('https://api.imagga.com/v2/uploads',
                auth=(key, secret),files={'image': open(f1.filename, 'rb')})
    res_post = pic1.json()['result']['upload_id']
    pic2 = requests.get('https://api.imagga.com/v2/tags',
                auth=(key, secret),params={'image_upload_id': res_post})
    pic3 = pic2.json()['result']['tags'][0]['tag']['en']
    pic2 = requests.get('http://api.giphy.com/v1/gifs/search',
                params={'q': pic3,'api_key': 'N211bT8F3qUun7CjtfqWICskzyxFAoTx'})
    sel = pic2.json()['data']
    add = []
    for i in range(0, 10):
        sels = sel[i]['images']['fixed_height']['url']
        add.append(sels)
    return render_template('search.html', sels=tuple(add))
if __name__ == '__main__':
    app.run(debug=True)